"""Benchmark generators."""
