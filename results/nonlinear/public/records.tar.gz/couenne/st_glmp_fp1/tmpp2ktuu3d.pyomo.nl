g3 1 1 0	# problem unknown
 4 8 1 0 2 	# vars, constraints, objectives, ranges, eqns
 0 1 0 0 0 0	# nonlinear constrs, objs; ccons: lin, nonlin, nd, nzlb
 0 0	# network constraints: nonlinear, linear
 0 2 0 	# nonlinear vars in constraints, objectives, both
 0 0 0 1	# linear network variables; functions; arith, flags
 0 0 0 0 0 	# discrete variables: binary, integer, nonlinear (b,c,o)
 18 2 	# nonzeros in Jacobian, obj. gradient
 0 0	# max name lengths: constraints, variables
 0 0 0 0 0	# common exprs: b,c,o,c1,o1
C0
n0
C1
n0
C2
n0
C3
n0
C4
n0
C5
n0
C6
n0
C7
n0
O0 0
o2
v0
v1
x4
0 0.0
1 0.0
2 -2.5
3 5.0
r
1 14.0
1 10.0
1 0.0
1 -6.0
1 -6.0
1 3.0
4 0.0
4 -7.0
b
3
3
0 -10.0 5.0
0 -10.0 20.0
k3
1
2
10
J0 2
2 2.0
3 1
J1 2
2 1
3 1
J2 2
2 -4.0
3 1
J3 2
2 -2.0
3 -1.0
J4 2
2 -1.0
3 -2.0
J5 2
2 1
3 -1.0
J6 3
0 -1.0
2 1
3 1
J7 3
1 -1.0
2 1
3 -1.0
G0 2
0 0
1 0
