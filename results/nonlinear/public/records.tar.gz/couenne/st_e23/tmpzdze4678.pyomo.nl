g3 1 1 0	# problem unknown
 2 2 1 0 0 	# vars, constraints, objectives, ranges, eqns
 0 1 0 0 0 0	# nonlinear constrs, objs; ccons: lin, nonlin, nd, nzlb
 0 0	# network constraints: nonlinear, linear
 0 2 0 	# nonlinear vars in constraints, objectives, both
 0 0 0 1	# linear network variables; functions; arith, flags
 0 0 0 0 0 	# discrete variables: binary, integer, nonlinear (b,c,o)
 4 2 	# nonzeros in Jacobian, obj. gradient
 0 0	# max name lengths: constraints, variables
 0 0 0 0 0	# common exprs: b,c,o,c1,o1
C0
n0
C1
n0
O0 0
o2
v0
v1
x2
0 2.5
1 2.5
r
1 3.0
1 3.0
b
0 0.0 5.0
0 0.0 5.0
k1
2
J0 2
0 -6.0
1 8.0
J1 2
0 3.0
1 -1.0
G0 2
0 -1.0
1 -1.0
