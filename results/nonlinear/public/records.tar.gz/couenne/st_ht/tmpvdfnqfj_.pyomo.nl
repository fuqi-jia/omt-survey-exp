g3 1 1 0	# problem unknown
 2 3 1 0 0 	# vars, constraints, objectives, ranges, eqns
 0 1 0 0 0 0	# nonlinear constrs, objs; ccons: lin, nonlin, nd, nzlb
 0 0	# network constraints: nonlinear, linear
 0 2 0 	# nonlinear vars in constraints, objectives, both
 0 0 0 1	# linear network variables; functions; arith, flags
 0 0 0 0 0 	# discrete variables: binary, integer, nonlinear (b,c,o)
 6 2 	# nonzeros in Jacobian, obj. gradient
 0 0	# max name lengths: constraints, variables
 0 0 0 0 0	# common exprs: b,c,o,c1,o1
C0
n0
C1
n0
C2
n0
O0 0
o0
o16
o2
v0
v0
o16
o2
v1
v1
x2
0 1.5
1 1.0
r
1 1.0
1 4.0
1 1.0
b
0 0.0 3.0
0 0.0 2.0
k1
3
J0 2
0 -2.0
1 1
J1 2
0 1
1 1
J2 2
0 0.5
1 -1.0
G0 2
0 2.4
1 1.2
